import React from 'react'
import styled from 'styled-components'

const Login = () => {
  return (
    <Div>
        hssd
    </Div>
  )
}

const Div = styled.div`
    /* box-sizing: border-box; */
    background-color: pink;
`;

export default Login
